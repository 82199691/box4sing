#!/system/bin/sh

rm -f "/data/adb/service.d/box4sing_service.sh" 2>/dev/null
rm -rf /data/adb/box4sing 2>/dev/null
